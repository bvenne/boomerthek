# API-Recherche für öffentlich-rechtliche deutsche Mediatheken

## Übersicht

Diese Recherche untersucht verfügbare APIs und Datenquellen für öffentlich-rechtliche deutsche Sender (ARD, ZDF, ARTE, 3SAT, WDR, BR, etc.) sowie IMDB-API-Integrationsmöglichkeiten für eine mobile Web-App.

## 1. Offizielle APIs für Programmdaten

### 1.1 ARD

#### ARD Developer Portal
- **URL**: https://developer.ard.de/
- **Status**: Eingeschränkter Zugang für interne Nutzung
- **Verfügbare APIs**:
  - **Core API v1**: Nur für interne Nutzung - Zugang zu Seiten, Widgets und Assets der ARD Mediathek
  - **Core API v2**: Neue Version für Content-Delivery zur ARD Mediathek - Zugang erfordert Registrierung

#### Tagesschau API
- **URL**: https://tagesschau.api.bund.dev/
- **Status**: Öffentlich verfügbar
- **Version**: 2.0.1 (OpenAPI Specification OAS3)
- **Endpunkte**:
  - `GET /api2u/homepage/` - Ausgewählte aktuelle Nachrichten
  - `GET /api2u/news/` - Aktuelle Nachrichten mit Filteroptionen
  - `GET /api2u/channels/` - Informationen zu Kanälen und Live-Streams
  - `GET /api2u/search/` - Suchfunktionalität
- **Nutzungsbedingungen**: Nur private, nicht-kommerzielle Nutzung

#### ARD Eventhub API
- **URL**: https://eventhub-ingest.ard.de/openapi/
- **Version**: 1.10.1 (OAS 3.0)
- **Zweck**: Verteilung von Live-Metadaten für Radiosendungen
- **Authentifizierung**: Login-System erforderlich

### 1.2 ZDF

#### ZDF Developer Portal
- **URL**: https://developer.zdf.de/
- **Status**: Eingeschränkter Zugang
- **Zugangsvoraussetzungen**: 
  - Nur für autorisierte Partner und ZDF-Entwickler
  - Registrierung über `api-dev-prod@zdf.de` erforderlich
  - Projektbeschreibung notwendig

### 1.3 ARTE

#### ARTE.TV API
- **Status**: Technisch vorhanden, aber durch CORS-Policy eingeschränkt
- **Problem**: Cross-Origin Resource Sharing verhindert externen Zugriff
- **Funktionalität**: Video-Metadaten (war verfügbar für Entwickler-Tools)

### 1.4 3SAT, WDR, BR

- **Offizielle APIs**: Keine öffentlich verfügbaren APIs identifiziert
- **Status**: Keine direkten API-Endpunkte für diese Sender verfügbar

## 2. Verfügbare Metadaten

### 2.1 Tagesschau API (ARD)
- **Nachrichten-Metadaten**:
  - Titel, Beschreibung, Datum/Zeit
  - Kategorie (ressort): inland, ausland, wirtschaft, sport, video, investigativ, wissen
  - Regionalfilter nach Bundesländern
  - Multimedia-Inhalte (Videos, Bilder)
  - Breaking News Status

### 2.2 ARD Mediathek (über Core APIs)
- **Titel-Metadaten**:
  - Titel, Beschreibung, Thema
  - Sender-Information
  - Dauer, Genre
  - Verfügbarkeitsdatum
  - Video-URLs in verschiedenen Qualitäten
  - Untertitel und Audiodeskription

### 2.3 MediathekViewWeb API (Drittanbieter)
- **Verfügbare Felder**:
  - `channel` (Sender)
  - `topic` (Thema)
  - `title` (Titel)
  - `description` (Beschreibung)
  - `timestamp` (Veröffentlichungsdatum)
  - `duration` (Dauer in Sekunden)
  - `size` (Dateigröße)
  - `url_website` (Website-URL)
  - `url_video` (Video-URL)
  - `url_video_low` (Niedrige Qualität)
  - `url_video_hd` (HD-Qualität)

## 3. Aktualität der Daten

### 3.1 Tagesschau API
- **Update-Frequenz**: Real-time/Live-Updates
- **Verfügbarkeit**: Aktuelle Nachrichten und Eilmeldungen sofort verfügbar

### 3.2 MediathekViewWeb
- **Update-Frequenz**: Täglich aktualisiert
- **Datenquelle**: Aggregiert von MediathekView-Projekt
- **Verfügbarkeit**: Umfasst alle aktuellen Sendungen der teilnehmenden Sender

### 3.3 ARD/ZDF Mediatheken
- **Update-Frequenz**: Live-Updates bei Neuveröffentlichungen
- **Retention**: Abhängig von Lizenzvereinbarungen (meist 7-30 Tage)

## 4. Technische Beschränkungen und Nutzungsbedingungen

### 4.1 Tagesschau API
- **Rate Limit**: Maximal 60 Abrufe pro Stunde
- **Nutzung**: Nur private, nicht-kommerzielle Nutzung gestattet
- **Veröffentlichung**: Nicht erlaubt (Ausnahme: CC-lizenzierte Inhalte)
- **Format**: JSON-Antworten

### 4.2 ARD Core APIs
- **Zugang**: Nur interne Nutzung
- **Authentifizierung**: API-Key erforderlich
- **Registrierung**: Über ARD Developer Portal

### 4.3 ZDF Developer Portal
- **Zugang**: Nur autorisierte Partner
- **Registrierung**: Projektbeschreibung erforderlich
- **Bearbeitungszeit**: Nicht spezifiziert

### 4.4 MediathekViewWeb API
- **Endpunkt**: `https://mediathekviewweb.de/api/query`
- **Methode**: POST mit JSON-Body
- **Content-Type**: `text/plain` (wichtig für Parsing)
- **Rate Limit**: Keine explizite Begrenzung dokumentiert
- **Lizenz**: GPL-3.0 (Open Source)

#### Abfrage-Parameter:
```json
{
  "queries": [
    {"fields": ["title", "topic"], "query": "suchbegriff"},
    {"fields": ["channel"], "query": "ard"}
  ],
  "sortBy": "timestamp",
  "sortOrder": "desc",
  "future": false,
  "offset": 0,
  "size": 100,
  "duration_min": 20,
  "duration_max": 3600
}
```

#### Unterstützte Sender:
- ARD (Das Erste) und regionale Sender: BR, HR, MDR, NDR, RBB, SR, SWR, WDR
- ZDF, ZDFinfo, ZDFneo, zdf-tivi
- Gemeinschaftsprogramme: 3Sat, Arte, Funk, Kika, Phoenix
- Weitere: DW TV, ORF, SRF

## 5. IMDB-API Zugang und Kosten

### 5.1 Offizielle IMDB API (über AWS Data Exchange)

#### Kosten:
- **Kostenlose Testversion**: 1 Monat gratis
- **Essential Metadata**: $150.000 + zusätzliche Verbrauchskosten (12 Monate)
- **Box Office Mojo Paket**: $400.000 + zusätzliche Verbrauchskosten (12 Monate)

#### Voraussetzungen:
- AWS-Account erforderlich
- AWS Access Keys
- Abonnement-Antrag (Bearbeitung: 5 Werktage)

#### Funktionen:
- GraphQL API
- 9+ Millionen Titel, 12+ Millionen Namen
- Real-time Daten (ohne 24h Verzögerung)
- Suchfunktionalität
- Bewertungen von 1+ Milliarde Nutzern

### 5.2 Alternative IMDB-APIs

#### OMDb API (Open Movie Database)
- **Kostenlos**: 1.000 Abrufe/Tag
- **Bezahlt**: Ab $1/Monat via Patreon (unbegrenzte Abrufe)
- **Poster API**: Nur für Unterstützer (280.000+ Poster)
- **Endpunkt**: `http://www.omdbapi.com/?apikey=[key]&`

#### RapidAPI IMDB Alternativen
- **Movie Database API**: 
  - Kostenlos: 1.000 Abrufe/Tag
  - Bezahlt: Ab $10/Monat
- **IMDB-API**: JSON-Format, umfassende Filmdaten
- **Entertainment Data Hub**: Erweiterte Suchfunktionen

#### The Movie Database (TMDb)
- **Kostenlos**: Für nicht-kommerzielle Nutzung
- **Rate Limit**: 40 Anfragen/10 Sekunden
- **Kommerzielle Nutzung**: Direkte Verhandlung erforderlich
- **Funktionen**: Mehrsprachig, Community-Content

### 5.3 Kosten-Nutzen-Analyse

| API | Kostenlos | Bezahlt | Ideal für |
|-----|-----------|---------|-----------|
| OMDb | 1.000/Tag | $1/Monat | Einfache Filmsuche |
| TMDb | Ja (nicht-kommerziell) | Verhandlung | Umfassende Entertainment-App |
| RapidAPI | Begrenzt | $10-50/Monat | Kommerzielle Projekte |
| Offizielle IMDB | 1 Monat | $150.000+ | Enterprise-Anwendungen |

## 6. Alternative Datenquellen

### 6.1 MediathekViewWeb (Empfohlen)
- **Typ**: Community-Projekt (Open Source)
- **Abdeckung**: Alle wichtigen öffentlich-rechtlichen Sender
- **Vorteile**: 
  - Kostenlos und ohne Registrierung
  - Täglich aktualisiert
  - Umfassende Metadaten
  - Direktzugriff auf Video-URLs
- **Nachteile**: 
  - Keine offizielle API
  - Abhängigkeit von Drittanbieter

### 6.2 Python-Bibliotheken

#### ardmediathek (PyPI)
- **Version**: 1.2.0 (Januar 2025)
- **Lizenz**: GPLv3
- **Funktionen**: Client-Library für ARD Mediathek API
- **Installation**: `pip install ardmediathek`

#### MediathekArr
- **Typ**: Integration in *arr-Stack (Sonarr, Radarr, Prowlarr)
- **Funktionen**: 
  - Automatischer Download
  - Metadaten-Matching
  - Untertitel-Unterstützung
  - MKV-Erstellung
- **Installation**: Docker-Container

### 6.3 Web Scraping (Alternative)

#### Apify IMDB Scraper
- **Kosten**: $0.30 für 1.000 Ergebnisse
- **Funktionen**: 
  - Anpassbare Datenextraktion
  - Proxy-Unterstützung
  - Export in JSON/CSV/Excel
- **Legal**: Web Scraping öffentlicher Daten ist legal

#### Selbst-entwickelte Scraper
- **Risiken**: 
  - Rechtliche Grauzonen
  - Änderungen der Website-Struktur
  - Rate-Limiting/Blockierungen
- **Empfehlung**: Nur als letzter Ausweg

### 6.4 Kostenlose IMDB-Datensätze

#### IMDB Non-Commercial Datasets
- **URL**: https://datasets.imdbws.com/
- **Format**: TSV (Tab-separated values)
- **Update**: Täglich
- **Lizenz**: Nur für persönliche/nicht-kommerzielle Nutzung

**Verfügbare Dateien**:
- `title.basics.tsv.gz` - Grundlegende Titel-Informationen
- `title.ratings.tsv.gz` - Bewertungen und Stimmen
- `title.crew.tsv.gz` - Regisseure und Autoren
- `title.principals.tsv.gz` - Hauptdarsteller und Crew
- `name.basics.tsv.gz` - Personen-Informationen

## Empfehlungen für die Mobile Web-App

### 1. Kurzfristige Lösung (MVP)
- **Programmdaten**: MediathekViewWeb API
- **IMDB-Bewertungen**: OMDb API ($1/Monat)
- **Implementierung**: REST-API mit JSON-Responses
- **Kosten**: ~$1-12/Monat

### 2. Langfristige Lösung (Skalierung)
- **Programmdaten**: Offizielle APIs (ARD Tagesschau + ZDF Partner-Zugang)
- **IMDB-Bewertungen**: TMDb API (kostenlos) oder RapidAPI (bezahlt)
- **Caching**: Redis/Memcached für Performance
- **Kosten**: $50-200/Monat (je nach Nutzung)

### 3. Enterprise-Lösung
- **Programmdaten**: Direkte Partnerships mit ARD/ZDF
- **IMDB-Bewertungen**: Offizielle IMDB API (AWS Data Exchange)
- **Infrastruktur**: AWS/Azure mit CDN
- **Kosten**: $150.000+ jährlich

### 4. Technische Implementierung

#### Architektur-Empfehlung:
```
Frontend (React/Vue) 
    ↓
Backend API (Node.js/Python)
    ↓
Datenquellen:
├── MediathekViewWeb API
├── OMDb API
└── Caching Layer (Redis)
```

#### Beispiel-Integration:
```javascript
// MediathekViewWeb Abfrage
const searchMediathek = async (query) => {
  const response = await fetch('https://mediathekviewweb.de/api/query', {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: JSON.stringify({
      queries: [{ fields: ['title'], query }],
      size: 50
    })
  });
  return await response.json();
};

// OMDb IMDB-Bewertung
const getIMDBRating = async (title) => {
  const response = await fetch(
    `https://www.omdbapi.com/?apikey=${API_KEY}&t=${title}`
  );
  return await response.json();
};
```

## Fazit

Die Entwicklung einer mobilen Web-App für öffentlich-rechtliche deutsche Medieninhalte mit IMDB-Bewertungen ist technisch machbar, jedoch mit einigen Herausforderungen verbunden:

**Herausforderungen**:
- Keine einheitliche offizielle API für alle Sender
- Eingeschränkter Zugang zu offiziellen APIs
- Hohe Kosten für offizielle IMDB-API

**Lösungsansätze**:
- MediathekViewWeb API als zentrale Datenquelle
- OMDb API für kostengünstige IMDB-Integration
- Schrittweise Migration zu offiziellen APIs

**Empfohlener Entwicklungsansatz**:
1. Start mit MediathekViewWeb + OMDb APIs
2. Implementierung von Caching und Performance-Optimierung
3. Aufbau von Partnerships mit ARD/ZDF
4. Schrittweise Migration zu offiziellen APIs

Die Kombination aus MediathekViewWeb und OMDb APIs bietet eine solide Grundlage für den Start des Projekts mit überschaubaren Kosten und guter Datenqualität.
