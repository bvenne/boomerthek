# Technische Wiedergabemöglichkeiten für deutsche Mediatheken

## Übersicht

Diese Recherche untersucht die technischen Möglichkeiten zur direkten Wiedergabe von Inhalten aus deutschen Mediatheken in einer Web-App. Basierend auf der vorherigen API-Recherche (MediathekViewWeb als Hauptdatenquelle) werden hier konkrete Implementierungsansätze für die Videowiedergabe analysiert.

## 1. Video-Embedding Möglichkeiten

### 1.1 Offizielle Player-APIs

**Status**: Keine öffentlich verfügbaren Player-APIs gefunden

- **ARD Developer Portal**: Beschränkter Zugang, keine dokumentierte Player-API für externes Embedding
- **ZDF Developer Portal**: Nur für autorisierte Partner, keine öffentliche Player-API
- **ARTE**: Technisch vorhanden, aber durch CORS-Policy eingeschränkt

**Verfügbare APIs**:
- ARD Core API v1/v2: Nur interne Nutzung
- Tagesschau API: Nur Metadaten, keine Wiedergabe-Funktionalität
- ZDF TMD API: Erfordert Registrierung und Projektbeschreibung

### 1.2 Alternative Embedding-Ansätze

**MediathekViewWeb als Datenquelle**:
- Liefert direkte Video-URLs in verschiedenen Qualitäten
- Felder: `url_video`, `url_video_low`, `url_video_hd`
- Unterstützt HLS-Streams (`.m3u8`) und DASH-Manifeste

**Implementierungsempfehlung**:
```javascript
// MediathekViewWeb API Abfrage
const getVideoStream = async (searchQuery) => {
  const response = await fetch('https://mediathekviewweb.de/api/query', {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: JSON.stringify({
      queries: [{ fields: ['title', 'channel'], query: searchQuery }],
      size: 50,
      sortBy: 'timestamp',
      sortOrder: 'desc'
    })
  });
  return await response.json();
};
```

## 2. CORS-Policies und Cross-Origin-Beschränkungen

### 2.1 MediathekViewWeb API

**CORS-Status**: ✅ Vollständig unterstützt
- Erlaubt direkte Client-Side-Zugriffe
- Keine Authentifizierung erforderlich
- Content-Type: `text/plain` (wichtig für CORS-Compliance)

### 2.2 Offizielle Mediatheken

**ARD Mediathek**:
- Keine offizielle CORS-Unterstützung für externe Zugriffe
- API-Zugang nur intern oder mit Registrierung
- HLS-Streams über Akamai CDN (`zdf-hls-15.akamaized.net`)

**ZDF Mediathek**:
- Erfordert `Api-Auth` Bearer Token
- GraphQL API für Metadaten
- TMD API für Stream-URLs mit Geolocation-Einschränkungen

**ARTE**:
- Historisch durch CORS-Policy eingeschränkt
- Geoblocking außerhalb Deutschland/Frankreich
- Meist DRM-geschützt (Widevine)

### 2.3 Umgehungslösungen

**Proxy-Server Ansatz**:
```javascript
// Beispiel mit eigenem Proxy
const proxyRequest = async (targetUrl) => {
  const response = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url: targetUrl })
  });
  return await response.json();
};
```

**Serverseitige Verarbeitung**:
- Backend-Service für Stream-URL-Auflösung
- Caching der Metadaten
- CORS-Header-Manipulation

## 3. HLS/DASH Stream-Wiedergabe

### 3.1 Stream-Formate

**HLS (HTTP Live Streaming)**:
- Primäres Format der öffentlich-rechtlichen Sender
- `.m3u8` Manifest-Dateien
- Adaptive Bitrate-Streaming
- Separate Audio/Video-Streams möglich

**DASH (Dynamic Adaptive Streaming)**:
- Alternative zu HLS
- `.mpd` Manifest-Dateien
- Bessere Qualitätsauswahl
- Geringere Latenz

### 3.2 JavaScript-Bibliotheken

**HLS.js** (Empfohlen):
```javascript
import Hls from 'hls.js';

const video = document.getElementById('video');
const videoSrc = 'https://example.com/stream.m3u8';

if (Hls.isSupported()) {
  const hls = new Hls();
  hls.loadSource(videoSrc);
  hls.attachMedia(video);
  hls.on(Hls.Events.MANIFEST_PARSED, () => {
    video.play();
  });
} else if (video.canPlayType('application/vnd.apple.mpegurl')) {
  // Native HLS support (Safari)
  video.src = videoSrc;
  video.addEventListener('loadedmetadata', () => {
    video.play();
  });
}
```

**DASH.js**:
```javascript
import dashjs from 'dashjs';

const video = document.getElementById('video');
const player = dashjs.MediaPlayer().create();
player.initialize(video, 'https://example.com/stream.mpd', true);
```

### 3.3 Browser-Unterstützung

**Desktop**:
- Chrome: HLS.js/DASH.js erforderlich
- Firefox: HLS.js/DASH.js erforderlich
- Safari: Native HLS-Unterstützung
- Edge: HLS.js/DASH.js erforderlich

**Mobile**:
- iOS Safari: Native HLS-Unterstützung
- Android Chrome: HLS.js/DASH.js erforderlich
- iPadOS 13+: MSE-Unterstützung für HLS.js

## 4. Rechtliche Aspekte der Einbettung

### 4.1 Allgemeine Rechtslage

**Grundsätzlich erlaubt**:
- Embedding von frei zugänglichen Inhalten
- Keine "neue Öffentlichkeit" wird geschaffen
- Inhalte bleiben auf ursprünglichem Server

**Bedingungen**:
- Inhalte müssen frei zugänglich sein (keine Paywall)
- Keine technischen Schutzmaßnahmen umgehen
- Keine Änderung oder irreführende Darstellung

### 4.2 Spezifische Regelungen für Mediatheken

**Private Nutzung**: ✅ Generell erlaubt
- Embedding für private, nicht-kommerzielle Zwecke
- Sofortige Entfernung bei Rechteinhaberbenachrichtigung

**Kommerzielle Nutzung**: ⚠️ Eingeschränkt
- Erfordert explizite Zustimmung der Sender
- Beispiel: Joyn vs. ARD/ZDF (Münchener Landgericht)
- Höhere Sorgfaltspflicht für Unternehmen

### 4.3 Compliance-Empfehlungen

**Sicherheitsmaßnahmen**:
- Regelmäßige Überprüfung der Inhalte
- Implementierung von Takedown-Mechanismen
- Klare Nutzungsbedingungen
- Datenschutzerklärung für Drittanbieter-Inhalte

**Rechtliche Absicherung**:
- Konsultation von Medienrechtsspezialisten
- Implementierung von Content-ID-Systemen
- Monitoring von Rechteinhaberbenachrichtigungen

## 5. Alternative Lösungen

### 5.1 Iframe-Embedding

**Vorteile**:
- Einfache Implementierung
- Sandboxing-Sicherheit
- Automatische Updates

**Nachteile**:
- Keine Kontrolle über Player-Interface
- Eingeschränkte Anpassungsmöglichkeiten
- Potenzielle CORS-Probleme

**Implementierung**:
```html
<iframe 
  src="https://mediathek.example.com/embed/video123"
  width="640" 
  height="360"
  frameborder="0"
  allowfullscreen
  sandbox="allow-scripts allow-same-origin allow-popups">
</iframe>
```

### 5.2 Weiterleitung zu Original-Plattformen

**Deep-Link-Ansatz**:
```javascript
const redirectToMediathek = (videoUrl) => {
  // Prüfung auf mobile Geräte
  const isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  
  if (isMobile) {
    // Direkte Weiterleitung zur mobilen App
    window.location.href = videoUrl;
  } else {
    // Öffnen in neuem Tab
    window.open(videoUrl, '_blank');
  }
};
```

### 5.3 Hybride Lösungen

**Kombination verschiedener Ansätze**:
1. Primär: Direkte HLS/DASH-Wiedergabe
2. Fallback: Iframe-Embedding
3. Ultima Ratio: Weiterleitung

```javascript
const playVideo = async (videoData) => {
  try {
    // Versuch 1: Direkte HLS-Wiedergabe
    if (videoData.url_video.endsWith('.m3u8')) {
      await playHLSStream(videoData.url_video);
    } else {
      throw new Error('Kein HLS-Stream verfügbar');
    }
  } catch (error) {
    try {
      // Versuch 2: Iframe-Embedding
      await embedIframe(videoData.url_website);
    } catch (error) {
      // Versuch 3: Weiterleitung
      redirectToMediathek(videoData.url_website);
    }
  }
};
```

## 6. Mobile Optimierung

### 6.1 HTML5 Video Autoplay-Policies

**iOS Safari Anforderungen**:
- `playsinline` Attribut erforderlich
- `muted` für Autoplay notwendig
- `autoplay` nur bei stummen Videos

**Android Chrome**:
- Ähnliche Einschränkungen wie iOS
- Nutzerinteraktion für Audio-Wiedergabe erforderlich

**Implementierung**:
```html
<video 
  playsinline 
  autoplay 
  muted 
  controls
  poster="thumbnail.jpg"
  preload="metadata">
  <source src="video.mp4" type="video/mp4">
  <source src="video.webm" type="video/webm">
</video>
```

### 6.2 Performance-Optimierungen

**Adaptive Streaming**:
- Automatische Qualitätsanpassung
- Bandwidth-Detection
- Buffer-Management

**Caching-Strategien**:
```javascript
// Service Worker für Video-Caching
self.addEventListener('fetch', event => {
  if (event.request.url.includes('.m3u8')) {
    event.respondWith(
      caches.open('video-cache').then(cache => {
        return cache.match(event.request).then(response => {
          return response || fetch(event.request).then(fetchResponse => {
            cache.put(event.request, fetchResponse.clone());
            return fetchResponse;
          });
        });
      })
    );
  }
});
```

### 6.3 Responsive Design

**Flexible Video-Container**:
```css
.video-container {
  position: relative;
  width: 100%;
  height: 0;
  padding-bottom: 56.25%; /* 16:9 Aspect Ratio */
}

.video-container video {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}

@media (max-width: 768px) {
  .video-container {
    padding-bottom: 75%; /* 4:3 für mobile Geräte */
  }
}
```

## 7. Konkrete Implementierungsempfehlungen

### 7.1 Architektur-Empfehlung

```
Frontend (React/Vue/Angular)
    ├── Video Player Component
    │   ├── HLS.js Integration
    │   ├── DASH.js Fallback
    │   └── Mobile Optimizations
    │
    ├── API Service Layer
    │   ├── MediathekViewWeb Client
    │   ├── Stream URL Resolver
    │   └── Error Handling
    │
    └── Backend Proxy Service
        ├── CORS Header Management
        ├── Stream URL Caching
        └── Legal Compliance Monitoring
```

### 7.2 Technologie-Stack

**Frontend**:
- Video Player: HLS.js + DASH.js
- Framework: React/Vue.js
- Build Tool: Vite/Webpack
- PWA Features: Service Worker

**Backend**:
- Node.js/Express oder Python/FastAPI
- Redis für Caching
- MongoDB/PostgreSQL für Metadaten
- CDN für statische Assets

### 7.3 Entwicklungsroadmap

**Phase 1: MVP (4-6 Wochen)**
- MediathekViewWeb API Integration
- Basis HLS.js Player
- Einfache mobile Optimierung

**Phase 2: Verbesserungen (6-8 Wochen)**
- DASH.js Integration
- Erweiterte mobile Features
- Caching-Implementierung

**Phase 3: Enterprise Features (8-12 Wochen)**
- Rechtliche Compliance-Tools
- Analytics Integration
- Performance-Monitoring

### 7.4 Kosten-Nutzen-Analyse

**Entwicklungskosten**:
- MVP: 20.000 - 30.000 EUR
- Vollständige Implementierung: 50.000 - 80.000 EUR
- Laufende Wartung: 5.000 - 10.000 EUR/Jahr

**Betriebskosten**:
- Server/CDN: 200 - 500 EUR/Monat
- Monitoring/Analytics: 100 - 300 EUR/Monat
- Rechtliche Beratung: 2.000 - 5.000 EUR/Jahr

## 8. Risiken und Herausforderungen

### 8.1 Technische Risiken

**Stream-Verfügbarkeit**:
- Zeitlich begrenzte Verfügbarkeit von Inhalten
- Änderungen der Stream-URLs
- Qualitätsschwankungen

**Browser-Kompatibilität**:
- Unterschiedliche HLS/DASH-Unterstützung
- Mobile Safari Einschränkungen
- Autoplay-Policy-Änderungen

### 8.2 Rechtliche Risiken

**Urheberrechtsverletzungen**:
- Kommerzielle Nutzung ohne Erlaubnis
- Umgehung von Geoblocking
- Missachtung von Takedown-Notices

**Datenschutz**:
- DSGVO-Compliance bei Drittanbieter-Inhalten
- Cookie-Consent für eingebettete Player
- Nutzertracking durch externe Services

### 8.3 Mitigation-Strategien

**Technische Absicherung**:
- Fallback-Mechanismen implementieren
- Monitoring und Alerting
- Regelmäßige Updates der Dependencies

**Rechtliche Absicherung**:
- Laufende Rechtsberatung
- Compliance-Monitoring
- Schnelle Reaktion auf Beschwerden

## 9. Fazit und Empfehlungen

### 9.1 Bevorzugter Ansatz

**Hybride Lösung mit MediathekViewWeb**:
1. **Primär**: HLS.js für direkte Stream-Wiedergabe
2. **Fallback**: Iframe-Embedding wo technisch möglich
3. **Ultima Ratio**: Weiterleitung zu Original-Plattformen

### 9.2 Kritische Erfolgsfaktoren

**Technisch**:
- Zuverlässige Stream-URL-Auflösung
- Robuste Error-Handling-Mechanismen
- Optimierte mobile Performance

**Rechtlich**:
- Klare Nutzungsbedingungen
- Proaktive Compliance-Maßnahmen
- Schnelle Reaktionsfähigkeit

### 9.3 Nächste Schritte

1. **Prototyp-Entwicklung** mit MediathekViewWeb API
2. **Rechtliche Prüfung** des Konzepts
3. **Pilotimplementierung** mit ausgewählten Inhalten
4. **Nutzertests** und Feedback-Integration
5. **Schrittweise Erweiterung** des Funktionsumfangs

## Anhang: Code-Beispiele

### A1. Vollständiger HLS.js Player

```javascript
import Hls from 'hls.js';

class MediathekPlayer {
  constructor(videoElement) {
    this.video = videoElement;
    this.hls = null;
    this.init();
  }

  init() {
    if (Hls.isSupported()) {
      this.hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 90
      });
      
      this.hls.on(Hls.Events.ERROR, (event, data) => {
        this.handleError(event, data);
      });
    }
  }

  loadStream(url) {
    if (this.hls) {
      this.hls.loadSource(url);
      this.hls.attachMedia(this.video);
      
      this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
        this.video.play().catch(e => {
          console.log('Autoplay verhindert:', e);
          this.showPlayButton();
        });
      });
    } else if (this.video.canPlayType('application/vnd.apple.mpegurl')) {
      this.video.src = url;
      this.video.addEventListener('loadedmetadata', () => {
        this.video.play().catch(e => {
          console.log('Autoplay verhindert:', e);
          this.showPlayButton();
        });
      });
    }
  }

  handleError(event, data) {
    console.error('HLS Error:', data);
    if (data.fatal) {
      switch (data.type) {
        case Hls.ErrorTypes.NETWORK_ERROR:
          this.hls.startLoad();
          break;
        case Hls.ErrorTypes.MEDIA_ERROR:
          this.hls.recoverMediaError();
          break;
        default:
          this.destroy();
          break;
      }
    }
  }

  showPlayButton() {
    const playButton = document.createElement('button');
    playButton.textContent = 'Play';
    playButton.className = 'play-button';
    playButton.onclick = () => {
      this.video.play();
      playButton.remove();
    };
    this.video.parentNode.appendChild(playButton);
  }

  destroy() {
    if (this.hls) {
      this.hls.destroy();
      this.hls = null;
    }
  }
}

// Verwendung
const videoElement = document.getElementById('video');
const player = new MediathekPlayer(videoElement);
player.loadStream('https://example.com/stream.m3u8');
```

### A2. MediathekViewWeb API Client

```javascript
class MediathekViewClient {
  constructor() {
    this.baseUrl = 'https://mediathekviewweb.de/api/query';
  }

  async search(query, options = {}) {
    const searchQuery = {
      queries: [{ 
        fields: options.fields || ['title', 'topic', 'channel'], 
        query: query 
      }],
      sortBy: options.sortBy || 'timestamp',
      sortOrder: options.sortOrder || 'desc',
      future: options.future || false,
      offset: options.offset || 0,
      size: options.size || 50,
      duration_min: options.duration_min || 0,
      duration_max: options.duration_max || 7200
    };

    try {
      const response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain' },
        body: JSON.stringify(searchQuery)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.result?.results || [];
    } catch (error) {
      console.error('MediathekView API Error:', error);
      throw error;
    }
  }

  async getStreamUrl(videoItem) {
    // Priorisierung: HD > Normal > Low
    if (videoItem.url_video_hd) {
      return videoItem.url_video_hd;
    } else if (videoItem.url_video) {
      return videoItem.url_video;
    } else if (videoItem.url_video_low) {
      return videoItem.url_video_low;
    }
    
    throw new Error('Keine Stream-URL verfügbar');
  }

  formatDuration(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    } else {
      return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
  }
}

// Verwendung
const client = new MediathekViewClient();
client.search('Tatort', { 
  fields: ['title', 'channel', 'topic'],
  size: 20,
  duration_min: 3600 // Mindestens 1 Stunde
}).then(results => {
  console.log('Gefundene Videos:', results);
  
  if (results.length > 0) {
    client.getStreamUrl(results[0]).then(streamUrl => {
      console.log('Stream URL:', streamUrl);
    });
  }
});
```

---

**Datum**: 16. Juli 2025  
**Version**: 1.0  
**Autor**: Abacus.AI Research Team  
**Basierend auf**: MediathekViewWeb API Research & technische Analyse öffentlich-rechtlicher Medieninhalte